<div id="main-ct">
    <div class="slide-text">
        <h3>Breaking News: भारतीयों ने तैयार की ओस से जल संचयन की तकनीक, इलाहाबाद के डॉक्टरों ने शुरू की ‘द 21 डॉक्टर्स’ मुहिम</h3>
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-lg-6 events-ct">
            <div class="row">
                <div class="col-xs-12">
                    <div class="border heading2 events">
                        Upcoming Events
                    </div>
                </div>
                <div class="col-xs-12">
                    <div class="bxslider-2-ct">
                        <ul class="bxslider-2">
                            <li class="slider-content">
                                <div class="row">
                                    <div class="col-xs-3"><img src="./abhnews/src/img/2.jpg" /></div>
                                    <div class="col-xs-6">
                                        <span>
                                            <div class="event-name">Ev rama swami periyar jyanti vip rod fatepur</div>
                                            <div class="event-detail">We are gathering in orai for jayanti divas</div>
                                        </span>
                                    </div>
                                    <div class="date">
                                        <div>17 Sep 2017</div>
                                        <div class="white-triangle"></div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class="col-xs-3"><img src="./abhnews/src/img/3.jpg" /></div>
                                    <div class="col-xs-6">
                                        <span>
                                            <div class="event-name">Gather for Pal Samaj Seva</div>
                                            <div class="event-detail">We are gathering in orai for the good of our samaj in Orai</div>
                                        </span>
                                    </div>
                                    <div class="date">
                                        <div>02 Jan - 04 Jan</div>
                                        <div class="white-triangle"></div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class="col-xs-3"><img src="./abhnews/src/img/4.jpg" /></div>
                                    <div class="col-xs-6">
                                        <span>
                                            <div class="event-name">Gather for Pal Samaj Seva</div>
                                            <div class="event-detail">We are gathering in orai for the good of our samaj in Orai</div>
                                        </span>
                                    </div>
                                    <div class="date">
                                        <div>02 Jan - 04 Jan</div>
                                        <div class="white-triangle"></div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class="col-xs-3"><img src="./abhnews/src/img/2.jpg" /></div>
                                    <div class="col-xs-6">
                                        <span>
                                            <div class="event-name">Gather for Pal Samaj Seva</div>
                                            <div class="event-detail">We are gathering in orai for the good of our samaj in Orai</div>
                                        </span>
                                    </div>
                                    <div class="date">
                                        <div>02 Jan - 04 Jan</div>
                                        <div class="white-triangle"></div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class="col-xs-3"><img src="./abhnews/src/img/3.jpg" /></div>
                                    <div class="col-xs-6">
                                        <span>
                                            <div class="event-name">Gather for Pal Samaj Seva</div>
                                            <div class="event-detail">We are gathering in orai for the good of our samaj in Orai</div>
                                        </span>
                                    </div>
                                    <div class="date">
                                        <div>02 Jan - 04 Jan</div>
                                        <div class="white-triangle"></div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="row">
                                    <div class="col-xs-3"><img src="./abhnews/src/img/4.jpg" /></div>
                                    <div class="col-xs-6">
                                        <span>
                                            <div class="event-name">Gather for Pal Samaj Seva</div>
                                            <div class="event-detail">We are gathering in orai for the good of our samaj in Orai</div>
                                        </span>
                                    </div>
                                    <div class="date">
                                        <div>02 Jan - 04 Jan</div>
                                        <div class="white-triangle"></div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-lg-6">
            <div class="col-xs-12 big-news">
                <img class="img-responsive" src="./abhnews/src/img/news/ahilyabai.jpg" />
                <div class="news-text-ct">
                    <!-- <div class="back-mask"></div> -->
                    <div class="news-heading"><strong>महारानी अहिल्या बाई होल्कर की 292 वीं जयंती पर बेटियों को ग्रेजुऐट की पढाई मुफ्त दिलाने की योजना का आरम्भ</strong></div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 bxslider-3-ct">
            <div class="border-bottom heading3">बड़ी ख़बरें</div>
            <ul class="bxslider-3">
                
                <li>
                    <img src="./abhnews/src/img/news/news3.jpg" />
                    <div class="news-heading">
                        <h4>शिक्षक दिवस पर गृहमंत्री राजनाथ सिंह देंगे लखनऊ मेट्रो का तोहफा</h4>
                    </div>
                    <div class="detail-news hidden">This is detail news</div>
                </li>
                <li>
                    <img src="./abhnews/src/img/news/news4.jpg" />
                    <div class="news-heading">
                        <h4>ट्रांसफार्मर में धमाके के साथ लगी आग,पास में खड़ी बाइक जलकर राख ,जानमाल का नुकसान</h4>
                    </div>
                    <div class="detail-news hidden">This is detail newsThis is detail news
                    </div>
                </li>
                <li>
                    <img src="./abhnews/src/img/news/news5.jpg" />
                    <div class="news-heading">
                        <h4>आधा घंटे के अंदर एक ही जगह पर दो युवकों से मोबाईल लूट</h4>
                    </div>
                    <div class="detail-news hidden">This is detail news</div>
                </li>
                <li>
                    <img src="./abhnews/src/img/news/news6.jpg" />
                    <div class="news-heading">
                        <h4>कैब्रिज स्कूल में बम की सूचना से मचा हड़कम्म</h4>
                    </div>
                    <div class="detail-news hidden">This is detail news</div>
                </li>
                <li>
                    <img src="./abhnews/src/img/news/news7.jpg" />
                    <div class="news-heading">
                        <h4>फर्जी आईडी बना फेसबुक पर डाली छात्रा की तश्वीरें</h4>
                    </div>
                    <div class="detail-news hidden">This is detail news</div>
                </li>
            </ul>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 bxslider-4-ct">
            <div class="border-bottom heading3 onlineNews">ताज़ा ख़बरें</div>
            <ul class="bxslider-4">

            </ul>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 team margin-bottom-20 bxslider">
            <div class="border-bottom heading3">हमारे संपादक</div>
            <ul class="bxslider-5">
                <li>
                    <a href="https://www.facebook.com/Pnsinghpalpramukhji/" target="_blank">
                        <div class="member text-center">
                            <img class="member-img img-responsive" src="./abhnews/src/img/team/prem.jpg" />
                            <div class="text-center member-name">Prem Narayan Singh Pal</div>
                            <div class="text-center member-desig">Chief Editor</div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="https://www.facebook.com/Anoop160" target="_blank">
                        <div class="  member text-center">
                            <img class="member-img img-responsive" src="./abhnews/src/img/team/anoop.jpg" />
                            <div class="text-center member-name">Anoop Pal</div>
                            <div class="text-center member-desig">Sub Editor</div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="https://www.facebook.com/Pnsinghpalpramukhji/" target="_blank">
                        <div class="  member text-center">
                            <img class="member-img img-responsive" src="./abhnews/src/img/team/deepakpal.jpg" />
                            <div class="text-center member-name">Deepak Pal</div>
                            <div class="text-center member-desig">Sub Editor</div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="https://www.facebook.com/Vikramved3899/" target="_blank">
                        <div class="  member text-center">
                            <img class="member-img img-responsive" src="./abhnews/src/img/team/drsurendravikramved.jpg" />
                            <div class="text-center member-name">Dr. Surendra Vikram Ved</div>
                            <div class="text-center member-desig">Sub Editor</div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="www.facebook.com/Yogipalchamri" target="_blank">
                        <div class="  member text-center">
                            <img class="member-img img-responsive" src="./abhnews/src/img/team/yogeshpal.jpg" />
                            <div class="text-center member-name">Yogesh Pal</div>
                            <div class="text-center member-desig">Sub Editor</div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="https://www.facebook.com/pintu.pal.1441/" target="_blank">
                        <div class="  member text-center">
                            <img class="member-img img-responsive" src="./abhnews/src/img/team/ramakantsingh.jpg" />
                            <div class="text-center member-name">Ramakant Singh</div>
                            <div class="text-center member-desig">Sub Editor</div>
                        </div>
                    </a>
                </li>
                 <li>
                    <a href="https://www.facebook.com/pintu.pal.1441/" target="_blank">
                        <div class="  member text-center">
                            <img class="member-img img-responsive" src="./abhnews/src/img/team/neerajkumar.jpg" />
                            <div class="text-center member-name">Neeraj Kumar</div>
                            <div class="text-center member-desig">Sub Editor</div>
                        </div>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <div class="row hidden ">
        <div class="col-xs-12 team margin-bottom-20">
            <div class="border-bottom heading3">हमारे संवाददाता</div>
            <ul class="bxslider-6">
                <li>
                    <a href="https://www.facebook.com/Pnsinghpalpramukhji/" target="_blank">
                        <div class="member text-center">
                            <img class="member-img img-responsive" src="./abhnews/src/img/reporters/prem.jpg" />
                            <div class="text-center member-name">Brajesh Baghel</div>
                            <div class="text-center member-desig">Prabhari [Gujraat]</div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="https://www.facebook.com/Anoop160" target="_blank">
                        <div class="  member text-center">
                            <img class="member-img img-responsive" src="./abhnews/src/img/reporters/anoop.jpg" />
                            <div class="text-center member-name">Satyendra Singh</div>
                            <div class="text-center member-desig">Prabhari [m.p.]</div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="https://www.facebook.com/Pnsinghpalpramukhji/" target="_blank">
                        <div class="  member text-center">
                            <img class="member-img img-responsive" src="./abhnews/src/img/reporters/deepakpal.jpg" />
                            <div class="text-center member-name">Deepak Pal</div>
                            <div class="text-center member-desig">Sub Editor</div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="https://www.facebook.com/Vikramved3899/" target="_blank">
                        <div class="  member text-center">
                            <img class="member-img img-responsive" src="./abhnews/src/img/reporters/drsurendravikramved.jpg" />
                            <div class="text-center member-name">Dr. Surendra Vikram Ved</div>
                            <div class="text-center member-desig">Sub Editor</div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="www.facebook.com/Yogipalchamri" target="_blank">
                        <div class="  member text-center">
                            <img class="member-img img-responsive" src="./abhnews/src/img/reporters/yogeshpal.jpg" />
                            <div class="text-center member-name">Yogesh Pal</div>
                            <div class="text-center member-desig">Sub Editor</div>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="https://www.facebook.com/pintu.pal.1441/" target="_blank">
                        <div class="  member text-center">
                            <img class="member-img img-responsive" src="./abhnews/src/img/reporters/ramakantsingh.jpg" />
                            <div class="text-center member-name">Ramakant Singh</div>
                            <div class="text-center member-desig">Sub Editor</div>
                        </div>
                    </a>
                </li>
                 <li>
                    <a href="https://www.facebook.com/pintu.pal.1441/" target="_blank">
                        <div class="  member text-center">
                            <img class="member-img img-responsive" src="./abhnews/src/img/reporters/neerajkumar.jpg" />
                            <div class="text-center member-name">Neeraj Kumar</div>
                            <div class="text-center member-desig">Sub Editor</div>
                        </div>
                          </a>
                    <li>
                      <li>
                          <a href="https://www.facebook.com/pintu.pal.1441/" target="_blank">
                        <div class="  member text-center">
                            <img class="member-img img-responsive" src="./abhnews/src/img/reporters/neerajkumar.jpg" />
                            <div class="text-center member-name">Neeraj Kumar</div>
                            <div class="text-center member-desig">Sub Editor</div>
                        </div>
                    </a>
                </li>
                
            </ul>
        </div>
    </div>
</div>
<script type="text/html" id="news-headline-tpl">
        <li>
            <div class="text-center">
                    <img class="news-img"/>
                    <div class="">
                        <h4 class="headline"></h4>
                    </div>
                    <div class="detail-news hidden"></div>
            </div>
        </li>
    </script>
    <div id="newsDescModal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
            </div>
        </div>
    </div>