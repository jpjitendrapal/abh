<footer class="footer">
        <div class="container">
            <div class="footer-links row">
                <div class="col-xs-3 text-center"><a href="http://www.abhnews.com/aboutus.php">About us</a></div>
                <div class="col-xs-3 text-center"><a href="http://www.abhnews.com/contactus.php">Contact us</a></div>
                <div class="col-xs-3 text-center"><a href="http://www.abhnews.com/contactus.php">Advertise with us</a></div>
                <div class="col-xs-3 text-center"><a href="https://snappy.appypie.com/index/app-download/app_id/3ae68b1d9974" target="_blank">Download App</a></div>
            </div>
        </div>
    </footer>
    
    <script src="./abhnews/src/js/index.js"></script>