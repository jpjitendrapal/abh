<!DOCTYPE html>
<!-- Created by: Jitendra Pal -->
<html>
<head>
    <?php include './pages/common/headlinks.php';?>

</head>
<body class="">
    <div class="container">
        <?php include './pages/common/header.php';?>
        <div class="" style="margin: 80px 50px;">
        
    <div class="row ">
        <img class="col-xs-12" alt="banner image" src="./abhnews/src/img/home/banner.jpeg" />
    </div>
          <p style="font-size: 20px; text-align: center;">
          हमारा उद्देश्य आपकी समस्या को अपनी आवाज बनाकर आपके समाधान का प्रयास करना है। <br/> आप समस्या बताये समाधान का प्रयास हम करेंगे।
</p>
        </div>
    </div>
    <?php include './pages/common/footer.php';?>
    <!-- Created by: Jitendra Pal -->
</body>

</html>