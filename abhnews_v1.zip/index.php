<!DOCTYPE html>
<!-- Created by: Jitendra Pal -->
<html>
<head>
    <?php include './pages/common/headlinks.php';?>
</head>
<body class="">
    <div class="container">
        <?php include './pages/common/header.php';?>
        <?php include './pages/home.php';?>
    </div>
    <?php include './pages/common/footer.php';?>
    <!-- Created by: Jitendra Pal -->
</body>

</html>