<footer class="footer">
        <div class="container">
            <div class="footer-links row">
                <div class="col-xs-3 text-center"><a href="/aboutus.html">About us</a></div>
                <div class="col-xs-3 text-center"><a href="/contactus.html">Contact us</a></div>
                <div class="col-xs-3 text-center"><a href="/advertisewithus.html">Advertise with us</a></div>
                <div class="col-xs-3 text-center"><a href="/tandc.html">Terms and Conditions</a></div>
            </div>
        </div>
    </footer>
    <script type="text/html" id="news-headline-tpl">
        <li>
            <div class="text-center">
                <a class="news-link" href="" target="_blank">
                    <img class="news-img"/>
                    <div class="">
                        <h4 class="headline"></h4>
                    </div>
                </a>
            </div>
        </li>
    </script>
    <script src="./abhnews/src/js/index.js"></script>